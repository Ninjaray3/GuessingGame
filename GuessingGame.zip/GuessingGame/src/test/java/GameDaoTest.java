import com.guessinggame.GuessingGame;
import com.guessinggame.data.*;
import com.guessinggame.models.*;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import java.sql.SQLException;
import java.util.List;

class GameDaoTest {
    private GameDao Gdao;

    @BeforeEach
    void setupBeforeEach() throws SQLException {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
        dataSource.setUrl("jdbc:mysql://localhost:3306/guessgamedbtest?serverTimezone=America/New_York&useSSL=false");
        dataSource.setUsername("root");
        dataSource.setPassword("cookies");
        Gdao = new GameDaoImpl(dataSource);
    }

    @Test
    void testAdd() {
        Game game = new Game("4564", "In Progress");
        Game result = Gdao.add(game);

        assertNotNull(result);
    }
    @Test
    void testGetAll() {
        List<Game> gameList = Gdao.getAll();
        for(Game games : gameList) {
            System.out.println(games);
        }
        assertFalse(gameList.isEmpty());
    }
    @Test
    void testFindById() {
        int gameid = 1;
        Game game = Gdao.findById(gameid);
        if(game != null) {
            System.out.println(game);
        }
        assertNotNull(game);
    }
    @Test
    void testUpdate() {
        Game game = new Game("9999", "Finished");
        int result = Gdao.update(game);

        assertTrue(result > 0);
    }
    @Test
    void testDeleteById() {
        int gameid = 3;
        int result = Gdao.deleteById(gameid);

     //   assertTrue(result > 0);
    }
}