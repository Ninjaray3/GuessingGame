import com.guessinggame.data.*;
import com.guessinggame.models.*;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import java.sql.SQLException;
import java.util.List;

public class RoundDaoTest {
    private RoundDao Rdao;
    private GameDao GDao;

    @BeforeEach
    void setupBeforeEach() throws SQLException {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
        dataSource.setUrl("jdbc:mysql://localhost:3306/guessgamedbtest?serverTimezone=America/New_York&useSSL=false");
        dataSource.setUsername("root");
        dataSource.setPassword("cookies");
        GDao = new GameDaoImpl(dataSource);
        Rdao = new RoundDaoImpl(dataSource);
    }
    @Test
    void testAdd() {
        Round round = new Round("2345");
        Game g2 = new Game();
        Game result = GDao.add(g2);

        assertNotNull(result);
    }
    @Test
    void testGetAll() {
        List<Round> roundList = Rdao.getAll(2);
        for(Round rounds : roundList) {
            System.out.println(rounds);
        }
        assertTrue(roundList.isEmpty());
    }
    @Test
    void testFindById() {
        int gameid = 2;
        Round round = Rdao.findById(gameid);
        if(round != null) {
            System.out.println(round);
        }
        assertNull(round);
    }
    @Test
    void testUpdate() {
        Round round = new Round("1", "2", "4238", 6285799, 3, 0);
        int result = Rdao.update(round);
        if(round != null) {
            System.out.println(round);
        }
        assertFalse(result > 0);
    }
    @Test
    void testDeleteById() {
        int gameid = 1;
        int result = Rdao.deleteById(gameid);

        assertFalse(result > 0);
    }
}


