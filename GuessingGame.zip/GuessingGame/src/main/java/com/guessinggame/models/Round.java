package com.guessinggame.models;

// Tip: Use: startTime  = System.nanoTime();

import com.guessinggame.controllers.Generator;

public class Round {
    public String gameId;
    public String roundId;
    public String guess;
    public long startTime;
    public int exact;
    public int partial;
    Generator gen = new Generator();

    public Round(String gameId, String roundId, String guess, long startTime, int exact, int partial) {
        super();
        this.gameId = gameId;
        this.roundId = roundId;
        this.guess = guess;
        this.startTime = startTime;
        this.exact = exact;
        this.partial = partial;
    }

    public Round(String guess, String gameId) {
        this.gameId = gameId;
        this.roundId = String.valueOf(gen.Generate());
        this.guess = guess;
        this.startTime = System.nanoTime();
        this.exact = 0;
        this.partial = 0;
    }

    public Round(Round round) {
        this.gameId = round.getGameId();
        this.roundId = String.valueOf(gen.Generate());
        this.guess = round.getGuess();
        this.startTime = System.nanoTime();
        this.exact = 0;
        this.partial = 0;
    }

    public Round(String guess) {
        super();
        this.guess = guess;
    }

    public String getGameId() { return gameId; }
    
    public void setGameId(String gameId) {
        this.gameId = gameId;
    }

    public String getRoundId() {
        return roundId;
    }

    public void setRoundId(String roundId) {
        this.roundId = roundId;
    }

    public String getGuess() {
        return guess;
    }

    public void setGuess(String guess) {
        this.guess = guess;
    }

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public int getExact() {
        return exact;
    }

    public void setExact(int exact) {
        this.exact = exact;
    }

    public int getPartial() {
        return partial;
    }

    public void setPartial(int partial) {
        this.partial = partial;
    }

   @Override
    public String toString() {
        return "Round{" +
                "gameId=" + gameId +
                ", roundId=" + roundId +
                ", guess=" + guess +
                ", startTime=" + startTime +
                ", exact=" + exact +
                ", partial=" + partial +
                '}';
    }

    
}
