package com.guessinggame.models;

import java.util.Objects;

public class Guess {
    private String gameId;
    private String guess;

    public String getGameId() {
        return gameId;
    }

    public void setGameId(String gameId) {
        this.gameId = gameId;
    }

    public String getGuess() {
        return guess;
    }

    public void setGuess(String guess) {
        this.guess = guess;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Guess guess1 = (Guess) o;
        return Objects.equals(gameId, guess1.gameId) && Objects.equals(guess, guess1.guess);
    }

    @Override
    public int hashCode() {
        return Objects.hash(gameId, guess);
    }
}
