package com.guessinggame.models;
import com.guessinggame.controllers.Generator;

public class Game {
    private String gameId;
    private String answer;
    private String status;
    Generator gen = new Generator();

    public Game(String answer, String status) {
        this.gameId = String.valueOf(gen.Generate());
        this.answer = answer;
        this.status = status;
    }
    public Game() {
        this.answer = "0";
        this.gameId = String.valueOf(gen.Generate());
        this.status = "In Progress";
    }
    public Game(String gameId) {
        super();
        this.gameId = gameId;
    }

    public Game(String gameId, String answer, String status) {
        this.gameId = gameId;
        this.answer = answer;
        this.status = status;
    }

    public String getGameId() {
        return this.gameId;
    }

    public void setGameId(String gameId) {
        this.gameId = gameId;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) { this.answer = answer; }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        if(status.equals("In Progress"))
        {
            answer = "Hidden";
        }
        return "Game{" +
                "gameId=" + gameId +
                ", answer=" + answer +
                ", status='" + status + '\'' +
                '}';
    }
}
