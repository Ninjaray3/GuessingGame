package com.guessinggame.data;

import com.guessinggame.models.Game;

import java.util.List;

public interface GameDao {

    Game add(Game game);

    List<Game> getAll();

    Game findById(int gameid);

    int update(Game game);

    int deleteById(int gameid);

}
