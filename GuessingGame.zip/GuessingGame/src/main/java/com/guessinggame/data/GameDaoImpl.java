package com.guessinggame.data;

import com.guessinggame.models.Game;

import com.mysql.cj.jdbc.MysqlDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import javax.sql.DataSource;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GameDaoImpl implements GameDao {

    @Autowired
    private JdbcTemplate jdbc;
    public DataSource dataSource = this.getDataSource();

    public GameDaoImpl(DataSource dataSource) throws SQLException {
        jdbc = new JdbcTemplate(dataSource);
    }
    public GameDaoImpl() throws SQLException {
        DataSource ds = dataSource;
        jdbc = new JdbcTemplate(ds);
    }
    @Override
    public int update(Game game) {
        String sql = "UPDATE Game SET answer = ?, status = ? WHERE gameid = ?";
        return jdbc.update(sql, game.getAnswer(), game.getStatus(), game.getGameId());
    }

    @Override
    public List<Game> getAll() {
        String sql = "SELECT * FROM Game";
        RowMapper<Game> rowMapper = (resultSet, i) -> {
            String gameid = resultSet.getString("gameid");
            String answer = resultSet.getString("answer");
            String status = resultSet.getString("status");
            if(status.equals("In Progress"))
            {
                answer = "Hidden";
            }
            return new Game(gameid, answer, status);
        };
        return jdbc.query(sql, rowMapper);
    }

    @Override
    public Game findById(int gameid) {
        String sql = "SELECT * FROM Game WHERE gameid=" + gameid;
        ResultSetExtractor<Game> extractor = resultSet -> {
            if(resultSet.next()) {
                String gameid1 = resultSet.getString("gameid");
                String answer = resultSet.getString("answer");
                String status = resultSet.getString("status");
                return new Game(gameid1, answer, status);
            }
            return null;
        };
        return jdbc.query(sql, extractor);
    }

    @Override
    public Game add(Game game) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        String sql = "INSERT INTO Game (answer, status) VALUES (?, ?)";

        jdbc.update(connection -> {
            PreparedStatement prep = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            prep.setString(1, game.getGameId());
            prep.setString(2, game.getStatus());
            return prep;
        }, keyHolder);
        game.setGameId(String.valueOf(keyHolder.getKey()));

        List<Integer> digits = new ArrayList<>();
        for(int i = 1; i < 10; i++){
            digits.add(i);
        }
        Collections.shuffle(digits);
        StringBuilder ray = new StringBuilder();
        for(int i = 0; i < 4; i++){
            ray.append(digits.get(i).toString());
        }
        game.setAnswer(ray.toString());
        String sql2 = "UPDATE Game SET answer = "+game.getAnswer()+" ORDER BY gameId DESC LIMIT 1";
        jdbc.update(sql2);
        return game;
    }

    @Override
    public int deleteById(int gameid) {
        String sql = "DELETE FROM Game WHERE gameid=" + gameid;
        return jdbc.update(sql);
    }

    public DataSource getDataSource() throws SQLException {
        MysqlDataSource ds = new MysqlDataSource();
        ds.setServerName("localhost");
        ds.setDatabaseName("guessgamedb");
        ds.setUser("root");
        ds.setPassword("cookies");
        ds.setServerTimezone("America/New_York");
        ds.setUseSSL(false);
        ds.setAllowPublicKeyRetrieval(true);

        return ds;
    }
}
