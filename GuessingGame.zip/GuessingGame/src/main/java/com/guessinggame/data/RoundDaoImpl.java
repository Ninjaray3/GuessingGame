package com.guessinggame.data;

import com.guessinggame.models.Game;
import com.guessinggame.models.Round;
import com.mysql.cj.jdbc.MysqlDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import javax.sql.DataSource;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

public class RoundDaoImpl implements RoundDao {

    @Autowired
    private JdbcTemplate jdbc;
    public DataSource dataSource = getDataSource();

    public RoundDaoImpl(DataSource dataSource) throws SQLException {
        jdbc = new JdbcTemplate(dataSource);
    }
    public RoundDaoImpl() throws SQLException {
        DataSource ds = dataSource;
        jdbc = new JdbcTemplate(ds);
    }

    @Override
    public int add(Round round, Game g1) {


        KeyHolder keyHolder = new GeneratedKeyHolder();
        String sql = "INSERT INTO Round (guess, gameid) VALUES (?, ?)";
        round.setStartTime(System.nanoTime());

        jdbc.update(connection -> {
            PreparedStatement prep = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            prep.setString(1, round.getRoundId());
            prep.setString(2, round.getGameId());
            return prep;
        }, keyHolder);
        round.setRoundId(String.valueOf(keyHolder.getKey()));
        String sql2 = "UPDATE Round SET guess = "+round.getGuess()+", starttime = "+round.getStartTime()+" WHERE gameid = "+round.getGameId();

        return jdbc.update(sql2);

    }

    @Override
    public List<Round> getAll(int gameId) {
        String sql = "SELECT * FROM round WHERE gameid = "+gameId;
        RowMapper<Round> rowMapper = (resultSet, i) -> {
            String gameId1 = resultSet.getString("gameid");
            String roundId = resultSet.getString("roundid");
            String guess = resultSet.getString("guess");
            long startTime = resultSet.getLong("starttime");
            int exact = resultSet.getInt("exact");
            int partial = resultSet.getInt("partial");
            return new Round(gameId1, roundId, guess, startTime, exact, partial);
        };
        return jdbc.query(sql, rowMapper);
    }

    @Override
    public Round findById(int gameId) {
        String sql = "SELECT * FROM round WHERE gameid = " + gameId;
        ResultSetExtractor<Round> extractor = resultSet -> {
            if(resultSet.next()) {
                String gameId1 = resultSet.getString("gameid");
                String roundId = resultSet.getString("roundid");
                String guess = resultSet.getString("guess");
                long startTime = resultSet.getLong("starttime");
                int exact = resultSet.getInt("exact");
                int partial = resultSet.getInt("partial");
                return new Round(gameId1, roundId, guess, startTime, exact, partial);
            }
            return null;
        };
        return jdbc.query(sql, extractor);
    }

    @Override
    public int update(Round round) {
        String sql = "UPDATE Round SET roundid=?, guess=?, starttime=?, exact=?, partial=? WHERE gameid=?";
        return jdbc.update(sql, round.getGameId(), round.getRoundId(), round.getGuess(), round.getStartTime(),round.getExact(), round.getPartial());
    }

    @Override
    public int deleteById(int gameId) {
        String sql = "DELETE FROM Round WHERE gameid = " + gameId;
        return jdbc.update(sql);
    }
    private static DataSource getDataSource() throws SQLException {
        MysqlDataSource ds = new MysqlDataSource();
        ds.setServerName("localhost");
        ds.setDatabaseName("guessgamedb");
        ds.setUser("root");
        ds.setPassword("cookies");
        ds.setServerTimezone("America/New_York");
        ds.setUseSSL(false);
        ds.setAllowPublicKeyRetrieval(true);

        return ds;
    }


}
