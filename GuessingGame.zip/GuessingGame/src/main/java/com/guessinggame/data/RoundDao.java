package com.guessinggame.data;

import com.guessinggame.models.Game;
import com.guessinggame.models.Round;

import java.util.List;

public interface RoundDao {
    int add(Round round, Game g1);

    List<Round> getAll(int gameId);

    Round findById(int gameid);

    int update(Round round);

    int deleteById(int gameid);
}
