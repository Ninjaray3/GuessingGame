package com.guessinggame.controllers;
import com.guessinggame.data.GameDaoImpl;
import com.guessinggame.data.RoundDaoImpl;
import com.guessinggame.models.Game;
import com.guessinggame.models.Round;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;


//REST controller for my application

@RestController
@RequestMapping(path="/game")
public class GuessingGameController {

    private GameDaoImpl GDaoImpl;
    private RoundDaoImpl RDaoImpl;
    private Game xGame;
    private Generator gen;

    @PostMapping("/begin")
    @ResponseStatus(HttpStatus.CREATED)
    public String begin() throws SQLException {
        Game g1 = new Game();
        // Typically in a service layer: Method for calculating an answer
        List<Integer> digits = new ArrayList<>();
        for(int i = 1; i < 10; i++){
            digits.add(i);
        }
        Collections.shuffle(digits);
        StringBuilder ray = new StringBuilder();
        for(int i = 0; i < 4; i++){
            ray.append(digits.get(i).toString());
        }
        g1.setAnswer(ray.toString());
        GameDaoImpl GDao = new GameDaoImpl();
        GDao.add(g1);
        return g1.getGameId();
    }
    @PostMapping("/guess")
    public Round guess(@RequestBody Map<String, String> json) throws SQLException {
        GameDaoImpl GDao = new GameDaoImpl();
        Game g1 = GDao.findById(Integer.parseInt(json.get("gameId")));
        RoundDaoImpl RDao = new RoundDaoImpl();
        Round round = new Round(json.get("guess"), json.get("gameId"));
        // Typically in a service layer: Method for calculating input exact/partial matches
        int[] guess = new int[g1.getAnswer().length()];
        for (int i = 0; i < g1.getAnswer().length(); i++)
        {
            guess[i] = g1.getAnswer().charAt(i) - '0';
        }
        int[] answer = new int[round.getGuess().length()];
        for (int i = 0; i < round.getGuess().length(); i++)
        {
            answer[i] = round.getGuess().charAt(i) - '0';
        }
        int exact = 0;
        int partial = 0;
        int gLeftSize = 0;
        int aLeftSize = 0;
        int[] guessLeft = new int[4];
        int[] answerLeft = new int[4];
        for (int i=0; i<4;i++) {
            if (guess[i] == answer[i]) {
                exact++;
            } else {
                guessLeft[gLeftSize++] = guess[i];
                answerLeft[aLeftSize++] = answer[i];
            }
        }
        for (int i=0; i<gLeftSize; i++) {
            for (int j=0; j<aLeftSize; j++) {
                if (guessLeft[i]==answerLeft[j]) {
                    partial++;
                    aLeftSize--;
                    answerLeft[j] = answerLeft[aLeftSize];
                    break;
                }
            }
        }
        round.setExact(exact);
        round.setPartial(partial);
        if (round.getGuess().equals(g1.getAnswer())) {
            round.setExact(4);
            round.setPartial(0);
            g1.setStatus("Finished");
        }
        else
            g1.setStatus("In Progress");
        RDao.add(round, g1);
        GDao.update(g1);
        return round;
    }
    @GetMapping("/game")
    public List<Game> game() throws SQLException {
        GameDaoImpl GDao = new GameDaoImpl();
        return GDao.getAll();
    }
    @GetMapping("/game/{gameId}")
    public Game gameById(@PathVariable("gameId") String gameId) throws SQLException {
        GameDaoImpl GDao = new GameDaoImpl();
        Game result = GDao.findById(Integer.parseInt(gameId));
        if(result.getStatus().equals("In Progress"))
        {
            result.setAnswer("Hidden");
        }
        return result;
    }
    @GetMapping("/rounds/{gameId}")
    public List<Round> rounds(@PathVariable("gameId") String gameId) throws SQLException {
        RoundDaoImpl RDao = new RoundDaoImpl();
        List<Round> y = RDao.getAll(Integer.parseInt(gameId));
        return y;
    }

}
