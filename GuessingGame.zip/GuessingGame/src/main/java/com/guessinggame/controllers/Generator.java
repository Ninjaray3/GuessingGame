package com.guessinggame.controllers;

import java.util.concurrent.atomic.AtomicInteger;

public class Generator {

    public AtomicInteger num = new AtomicInteger(1);
    public int id;

    public int Generate() {
        id = num.getAndIncrement();
        return id;
    }
}
